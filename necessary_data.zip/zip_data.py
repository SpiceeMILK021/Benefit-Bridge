from __future__ import annotations
import csv
import os
import sys


def _resource_path(name: str) -> str:
    try:
        base = sys._MEIPASS
    except AttributeError:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, name)


ZIP_COORDS: dict[str, tuple[float, float]] = {}
CITY_COORDS: dict[str, tuple[float, float]] = {}


def _load() -> None:
    path = _resource_path("uszips.csv")
    city_pop: dict[str, tuple[float, float, int]] = {}
    with open(path, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            z = row["zip"].strip().zfill(5)
            try:
                lat = float(row["lat"])
                lng = float(row["lng"])
            except (ValueError, KeyError):
                continue
            ZIP_COORDS[z] = (lat, lng)
            city = row["city"].strip().lower()
            try:
                pop = int(float(row.get("population") or 0))
            except ValueError:
                pop = 0
            if city not in city_pop or pop > city_pop[city][2]:
                city_pop[city] = (lat, lng, pop)
    for city, (lat, lng, _) in city_pop.items():
        CITY_COORDS[city] = (lat, lng)


_load()
